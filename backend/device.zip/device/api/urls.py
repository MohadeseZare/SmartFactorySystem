from django.urls import path
from .views import *

urlpatterns = [
    path('device/', DeviceView.as_view(), name='api-device'),
    path('device/<int:id>/', DetailDeviceView.as_view(), name='api-device-detail'),
    path('line-device/', LineDeviceView.as_view(), name='api-line-device'),
    path('report/', ReportDeviceView.as_view(), name='api-report'),
    # path('report/<int:id>/', .as_view(), name='api-report-log-details'),
    # path('report/excel/', .as_view(), name='api-report-excel'),
    # path('report/log/', .as_view(), name='api-report-log'),
    # path('receive-data/', .as_view(), name='api-receive-data'),
    path('live_data/', LiveDataView.as_view(), name='api-dashboard'),
    path('line_live_data/<product_line_id>', TileLiveView.as_view(), name='api-line-dashboard'),
    path('report_csv_file/', TileGetExcelView.as_view(), name='api_csv_download')
]
