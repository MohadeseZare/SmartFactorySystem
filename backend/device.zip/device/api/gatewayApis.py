def inlocal_server_live():
    return 'http://178.22.124.147:9017/gateway/livedata/'


def inlocal_local_live():
    return 'http://localhost:8080/gateway/livedata/'


def inserver_live():
    return 'http://localhost:7000/gatewaya/gateway/livedata/'


def inlocal_server_getLogs():
    return 'http://178.22.124.147:9017/gateway/api/getLogs/inPeriod/'


def inlocal_local_getLogs():
    return 'http://localhost:8080/gateway/api/getLogs/inPeriod/'

def inlocal_Line_report1():
    return 'tile log url1'

def inlocal_Line_report2():
    return 'tile log url2'

def inlocal_Line_report3():
    return 'tile log url3'

def inlocal_Line_report4():
    return 'tile log url4'

def inlocal_Line_report5():
    return 'tile log url5'

def inserver_getLogs():
    return 'http://localhost:7000/gatewaya/gateway/api/getLogs/inPeriod/'


def inlocal_local_getLogsData():
    return 'http://localhost:7000/gatewaya/gateway/api/getLogs/inPeriod/data/'


def inserver_line_live():
    return 'http://178.22.124.147:9017/gatewaya/packaging/liveData/'
