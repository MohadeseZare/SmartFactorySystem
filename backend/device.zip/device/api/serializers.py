from rest_framework import serializers
from device.models import Device, DeviceType, HistoryData, LineDevice


class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = '__all__'


class ReportDeviceSerializers(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = '__all__'


class LineDeviceSerializers(serializers.ModelSerializer):
    class Meta:
        model = LineDevice
        fields = '__all__'
