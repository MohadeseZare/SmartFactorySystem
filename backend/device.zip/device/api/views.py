import traceback
from datetime import datetime
from django.utils.dateparse import parse_datetime
from django.http import HttpResponse
import json
import requests
from rest_framework import generics
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework import status
from wsgiref.util import FileWrapper
import os
import csv

from device.api.serializers import *
from device.models import DeviceType, Device, HistoryData, LineDevice
from .gatewayApis import inlocal_local_getLogs, inlocal_server_getLogs, inserver_getLogs
from .gatewayApis import inlocal_server_live, inlocal_local_live, inserver_live, inserver_line_live
from .gatewayApis import inlocal_local_getLogsData, inlocal_Line_getLogsData
from .gatewayApis import inlocal_Line_report1, inlocal_Line_report2, inlocal_Line_report3
from .gatewayApis import inlocal_Line_report4, inlocal_Line_report5
from factory.models import *


def cal_logs(start_time, end_time, mac_address, pin, position, device_type):
    URL = inlocal_local_getLogsData()
    BODY = {
        "start_time": start_time,
        "end_time": end_time,
        "mac_address": mac_address,
        "pin": pin,
        "position": position,
        "type_data": device_type
    }
    logs_datas = requests.post(url=URL, data=BODY)
    print("body:", BODY)
    print("url", URL)
    print("logs return data:", logs_datas)
    data = logs_datas.json()

    return data


def cal_logs_aggrate(start_time, end_time, dur_time, mac_address, pin, position, device_type, report_id):
    URL = inserver_getLogs()
    BODY = {
        "start_time": start_time,
        "end_time": end_time,
        "dur_time": dur_time,
        "mac_address": mac_address,
        "pin": pin,
        "position": position,
        "type_data": device_type,
        "report_id": report_id
    }
    logs_datas = requests.post(url=URL, data=BODY)
    print("body:", BODY)
    print("url", URL)
    print("logs return data:", logs_datas)
    data = logs_datas.json()

    return data


def cal_logs_aggrate_special(start_time, end_time, dur_time, mac_address, pin, position, device_type, report_id,
                             p_start, p_end):
    URL = inserver_getLogs()
    BODY = {
        "start_time": start_time,
        "end_time": end_time,
        "dur_time": dur_time,
        "mac_address": mac_address,
        "pin": pin,
        "position": position,
        "type_data": device_type,
        "report_id": report_id,
        "p_start_time": p_start,
        "p_end_time": p_end
    }
    logs_datas = requests.post(url=URL, data=BODY)
    print("body:", BODY)
    print("url", URL)
    print("logs return data:", logs_datas)
    data = logs_datas.json()

    return data


def call_tile_logs(start_time, end_time, dur_time, mac_address, degree, report_id):
    if report_id == 1:
        URL = inlocal_Line_report1()
    elif report_id == 2:
        URL = inlocal_Line_report2()
    elif report_id == 3:
        URL = inlocal_Line_report3()
    elif report_id == 4:
        URL = inlocal_Line_report4()
    elif report_id == 5:
        URL = inlocal_Line_report5()
    BODY = {
        "start_time": start_time,
        "end_time": end_time,
        "dur_time": dur_time,
        "mac_address": mac_address,
        "degree": degree,
        "report_id": report_id
    }
    logs_datas = requests.post(url=URL, data=BODY)
    print("body:", BODY)
    print("url", URL)
    print("logs return data:", logs_datas)
    data = logs_datas.json()

    return data


class LineDeviceView(generics.ListCreateAPIView):
    queryset = LineDevice.objects.all()
    serializer_class = LineDeviceSerializers
    permission_classes = [AllowAny]


class DeviceView(generics.ListCreateAPIView):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        product_line_part = self.request.query_params.get('product_line_part')
        product_line = self.request.query_params.get('product_line')
        device_type = self.request.query_params.get('device_type')

        queryset = Device.objects.all()
        if product_line_part:
            queryset = queryset.filter(product_line_part=product_line_part)
        if product_line:
            queryset = queryset.filter(product_line_part__product_line=product_line)
        if device_type:
            queryset = queryset.filter(device_type=device_type)
        return queryset


class DetailDeviceView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer
    permission_classes = [AllowAny]
    lookup_field = 'id'


class DetailLineView(generics.RetrieveUpdateDestroyAPIView):
    queryset = LineDevice.objects.all()
    serializer_class = LineDeviceSerializers
    permission_classes = [AllowAny]
    lookup_field = 'id'


class ReportDeviceView(generics.RetrieveAPIView):  # get the data for show report
    queryset = Device.objects.all()

    def retrieve(self, request, *args, **kwargs):
        try:
            # sensorInLines = Device.objects.all()
            report_id = self.request.query_params.get('report_id')
            if report_id == "1":
                response = []
                device_id = self.request.query_params.get('device_id').split(",")
                for device_e in device_id:
                    device = Device.objects.get(id=device_e)
                    if self.request.query_params.get('dur_time'):
                        print("yes")
                        live_datas = cal_logs_aggrate(self.request.query_params.get('start_time'),
                                                      self.request.query_params.get('end_time'),
                                                      self.request.query_params.get('dur_time'),
                                                      device.mac_address, device.port, device.position,
                                                      device.device_type.id, report_id)
                    else:
                        live_datas = cal_logs(self.request.query_params.get('start_time'),
                                              self.request.query_params.get('end_time'), device.mac_address, device
                                              .port, device.position, device.device_type.id)
                    # print("lives_data", live_datas)
                    sensorInLines = Device.objects.get(id=device_e)
                    # for sensor in sensorInLines:
                    sensorRes = []
                    mac = sensorInLines.mac_address
                    # print(mac)
                    pin = sensorInLines.port
                    position = sensorInLines.position
                    sensor_data = -1
                    # sensorRes.append(SensorSerializer(sensor).data)
                    sensorDataRes = []
                    for gateway_data in live_datas:
                        # print("in other for")
                        # print(live_datas)
                        if gateway_data['mac_addr'] == mac and gateway_data['pin'] == pin and gateway_data[
                            'position'] == str(position):
                            if sensor_data == "None":
                                sensor_data = -1
                            else:
                                sensor_data = gateway_data['data']

                            sensorDataRes.append({"time": gateway_data['sendDataTime'], "sensor_data": sensor_data})
                            # print("sesnsor", SensorSerializer(sensor).data)
                    sensorRes = [{"id": sensorInLines.id, "name": sensorInLines.name, "pin": sensorInLines.port,
                                  "position": sensorInLines.position, "data": sensorDataRes}]
                    # sensorRes.append(sensorDataRes)
                    response.append((sensorRes))
                return Response((response), status=status.HTTP_200_OK)
            elif report_id == "2":
                response = []
                device_id = self.request.query_params.get('device_id').split(",")
                step_pin = 11
                time_pin = 12
                device_type_id = 1
                for device_e in device_id:
                    device = Device.objects.get(id=device_e)
                    if self.request.query_params.get('dur_time'):
                        print("yes")
                        live_datas = cal_logs_aggrate(self.request.query_params.get('start_time'),
                                                      self.request.query_params.get('end_time'),
                                                      self.request.query_params.get('dur_time'),
                                                      device.mac_address, device.port, device.position,
                                                      device.device_type.id, report_id)
                    else:
                        live_datas = cal_logs(self.request.query_params.get('start_time'),
                                              self.request.query_params.get('end_time'), device.mac_address, device
                                              .port, device.position, device.device_type.id)
                    # print("lives_data", live_datas)
                    sensorInLines = Device.objects.get(id=device_e)
                    # for sensor in sensorInLines:
                    sensorRes = []
                    mac = sensorInLines.mac_address
                    # print(mac)
                    pin = sensorInLines.port
                    position = sensorInLines.position
                    sensor_data = -1
                    # sensorRes.append(SensorSerializer(sensor).data)
                    sensorDataRes = []
                    for gateway_data in live_datas:
                        # print("in other for")
                        if gateway_data['mac_addr'] == mac and gateway_data['pin'] == "1" and gateway_data[
                            'position'] == str(position):
                            if sensor_data == "None":
                                sensor_data = -1
                            else:
                                sensor_data = gateway_data['data']

                            sensorDataRes.append({"time": gateway_data['sendDataTime'], "sensor_data": sensor_data})
                            # print("sesnsor", SensorSerializer(sensor).data)
                    sensorRes = [{"id": sensorInLines.id, "name": sensorInLines.name, "pin": sensorInLines.port,
                                  "position": sensorInLines.position, "data": sensorDataRes}]
                    # sensorRes.append(sensorDataRes)
                    response.append((sensorRes))
                return Response((response), status=status.HTTP_200_OK)
            elif report_id == "3":
                response = []
                setting_time = Settings.objects.filter(factory=1).last()
                input = json.loads(setting_time.inputs)
                p_start = parse_datetime(input['peek_barq'][0])
                p_end = parse_datetime(input['peek_barq'][1])
                print(p_start, type(p_start), p_start.time())
                device_id = self.request.query_params.get('device_id').split(",")
                for device_e in device_id:
                    device = Device.objects.get(id=device_e)
                    if self.request.query_params.get('dur_time'):

                        live_datas = cal_logs_aggrate_special(self.request.query_params.get('start_time'),
                                                              self.request.query_params.get('end_time'),
                                                              self.request.query_params.get('dur_time'),
                                                              device.mac_address, device.port, device.position,
                                                              device.device_type.id, report_id, p_start, p_end)
                    else:
                        live_datas = cal_logs(self.request.query_params.get('start_time'),
                                              self.request.query_params.get('end_time'), device.mac_address, device
                                              .port, device.position, device.device_type.id)
                    # print("lives_data", live_datas)
                    sensorInLines = Device.objects.get(id=device_e)
                    sensorRes = []
                    mac = sensorInLines.mac_address
                    pin = sensorInLines.port
                    position = sensorInLines.position
                    sensor_data = -1
                    sensorDataRes = []
                    for gateway_data in live_datas:
                        if gateway_data['mac_addr'] == mac and gateway_data['pin'] == "1" and gateway_data[
                            'position'] == str(position):
                            if sensor_data == "None":
                                sensor_data = -1
                            else:
                                sensor_data = gateway_data['data']

                            sensorDataRes.append({"time": gateway_data['sendDataTime'], "sensor_data": sensor_data})
                            # print("sesnsor", SensorSerializer(sensor).data)
                    sensorRes = [{"id": sensorInLines.id, "name": sensorInLines.name, "pin": sensorInLines.port,
                                  "position": sensorInLines.position, "data": sensorDataRes}]
                    response.append((sensorRes))
                return Response((response), status=status.HTTP_200_OK)
            return Response(status=status.HTTP_200_OK)
        except Device.DoesNotExist:
            return Response({"detail": "Sensor Not found."}, status=status.HTTP_404_NOT_FOUND)
        except:
            traceback.print_exc()
            return Response({"problem"}, status=status.HTTP_404_NOT_FOUND)


class LiveDataView(generics.RetrieveAPIView):
    def get_queryset(self):
        pass

    def retrieve(self, *args, **kwargs):
        product_line_id = self.request.query_params.get('product_line_id')
        sensorInLines = Device.objects.filter(product_line_part=product_line_id)
        response = []
        try:
            live_datas = requests.get(inserver_live())
            live_datas = live_datas.json()
            # print(live_datas)
            for sensor in sensorInLines:
                mac = sensor.mac_address
                pin = sensor.port
                position = sensor.position
                device_type = sensor.device_type
                sensor_data = "no data"
                for gateway_data in live_datas:
                    if gateway_data['mac_addr'] == mac and gateway_data['pin'] == pin and gateway_data[
                        'position'] == str(position) and gateway_data['type_data'] == device_type.id:
                        sensor_data = gateway_data['data']
                        # print("aaaaaaaaaaaaaaa", sensor_data)
                        if sensor_data == "None":
                            sensor_data = "no data"
                sensorRes = {"live_data": sensor_data}
                # print("bbbbbbbbbbbbbbbb", sensorRes)
                sensorRes.update(DeviceSerializer(sensor).data)
                # print(DeviceSerializer(sensor).data)
                response.append((sensorRes))
            return Response((response), status=status.HTTP_200_OK)
        except:
            traceback.print_exc()
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)


class TileLiveView(generics.RetrieveAPIView):
    lookup_field = ['product_line_id']

    def get_queryset(self):
        pass

    def retrieve(self, request, *args, **kwargs):
        sensorInLines = LineDevice.objects.get(id=self.kwargs["product_line_id"])
        try:
            live_datas = requests.get(inserver_line_live())
            live_datas = live_datas.json()
            for sensor in sensorInLines:
                mac = sensor.mac_address
                id = sensor.id
                name = sensor.name
                for gateway_data in live_datas:
                    if gateway_data['mac_addr'] == mac:
                        live_data = {'line_id': id, 'line_name': name,
                                     'time': str(datetime.fromtimestamp(gateway_data['datatime'])),
                                     'degree1': gateway_data['degree1'], 'degree2': gateway_data['degree2'],
                                     'degree3': gateway_data['degree3'], 'degree4': gateway_data['degree4'],
                                     'degree5': gateway_data['degree5'], 'degree6': gateway_data['degree6']}
                        json_live = json.dumps(live_data)
                        json_live_loaded = json.loads(json_live)

            return Response(json_live_loaded, status=status.HTTP_200_OK)
        except:
            traceback.print_exc()
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)


class TileDailyReportView(generics.RetrieveAPIView):
    lookup_field = ['product_line_id']

    def get_queryset(self):
        pass

    def retrieve(self, request, *args, **kwargs):
        sensorInLines = LineDevice.objects.get(id=self.kwargs['product_line_id'])
        try:
            logData = call_tile_logs(self.kwargs['start_time'], self.kwargs['end_time'], self.kwargs['dur_time'] * 60,
                                     sensorInLines['mac_address'], self.kwargs['degree'], self.kwargs['report_id'])
            report_response = []
            for log in logData:
                report_json = {'line_id': sensorInLines.id, 'line_name': sensorInLines.name,
                               'time': str(datetime.fromtimestamp(log['datatime'])),
                               'degree': log['degree']}
                json_live = json.dumps(report_json)
                json_live_loaded = json.loads(json_live)
                report_response.append(json_live_loaded)
            return Response(report_response, status=status.HTTP_200_OK)
        except:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)


class TileGetExcelView(generics.RetrieveAPIView):
    def get_queryset(self):
        pass

    def retrieve(self, request, *args, **kwargs):
        sensorInLines = LineDevice.objects.get(id=self.kwargs['product_line_id'])
        try:
            logData = call_tile_logs(self.kwargs['start_time'], self.kwargs['end_time'], self.kwargs['dur_time'] * 60,
                                     sensorInLines['mac_address'], self.kwargs['degree'], self.kwargs['report_id'])
        except:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)
        report_file_name = 'report' + str(self.kwargs['start_time']) + str(self.kwargs['end_time']) + '.csv'
        if os.path.exists(report_file_name):
            os.remove(report_file_name)
        report_file = open(report_file_name, 'x')
        report_title = ['id', 'name', 'time', 'amount']
        report_response = []
        for log in logData:
            report_lst = [sensorInLines.id, sensorInLines.name,
                          str(datetime.fromtimestamp(log['datatime'])), log['degree']]
            report_response.append(report_lst)
        with open(report_file_name, 'w')as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow(report_title)
            csv_writer.writerows(report_response)
        response = HttpResponse(FileWrapper(csv_file), content_type='whatever')
        response['Content-Disposition'] = 'attachment; filename="%s"' % report_file_name

        return Response(report_response, status=status.HTTP_200_OK)
